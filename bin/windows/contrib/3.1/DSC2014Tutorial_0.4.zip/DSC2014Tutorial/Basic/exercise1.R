my_vec <- c(1, 2, 5, 90, 37)
ind <- my_vec >= 5
sum(ind)
